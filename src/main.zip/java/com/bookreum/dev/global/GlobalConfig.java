package com.bookreum.dev.global;

public class GlobalConfig {

}
