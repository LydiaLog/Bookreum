package com.bookreum.dev.domain.book;

public class BookService {

}
