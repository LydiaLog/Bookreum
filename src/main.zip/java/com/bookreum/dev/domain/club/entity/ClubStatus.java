package com.bookreum.dev.domain.club.entity;

public enum ClubStatus {
    OPEN,
    MATCHED,
    CLOSED
}

