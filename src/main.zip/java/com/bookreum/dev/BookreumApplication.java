package com.bookreum.dev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookreumApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookreumApplication.class, args);
	}

}
